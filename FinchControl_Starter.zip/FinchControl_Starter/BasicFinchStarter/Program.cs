﻿using FinchAPI;
using System;

namespace FinchControl_Starter
{
    class Program
    {
        /// <summary>
        /// basic starter solution for the Finch robot
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            // **************************************************
            //
            // Assignment: Finch Control
            // Author: (your name here)
            // Creation Date: (your date here)
            //
            // **************************************************

            //
            // create (instantiate) a new finch object
            //
            Finch myFinch;
            myFinch = new Finch();

            //
            // connect to the finch robot using the finch method
            //
            myFinch.connect();

            //
            // begin application code here
            //

            myFinch.setLED(255, 255, 255);
            Console.ReadKey();
            //
            // end application code here
            //

            //
            // disconnect from the finch robot using the finch method
            //
            myFinch.disConnect();
        }
    }
}
